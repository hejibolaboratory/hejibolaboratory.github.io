import ccm
ccm.run('paired',20,threshold=[-1.6,-1.7],latency=[0.3,0.325,0.35,0.375,0.4])
