import ccm
ccm.run('paired',20,threshold=[-1.8,-1.9,-2,-2.1,-2.2],latency=[0.3,0.325,0.35,0.375,0.4])
