import ccm
ccm.run('paired',20,threshold=[-1,-1.5,-2,-2.5])
