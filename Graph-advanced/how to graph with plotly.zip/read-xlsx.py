import pandas as pd
 
file = "/Users/ucdlab/Documents/GitHub/hejibolaboratory.github.io/Graph-advanced/kss-score.xlsx"
data = pd.read_excel(file) #reading file
 
print(data)