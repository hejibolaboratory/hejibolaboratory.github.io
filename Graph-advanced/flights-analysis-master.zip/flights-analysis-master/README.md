# Flight data visualisation with Pandas and Matplotlib

An example on how to visualize flight data using Matplotlib and Pandas on Python.

The whole story: https://blog.hugo-larcher.com/flight-data-visualisation-with-pandas-and-matplotlib-ebbd13038647#.fi8yu7iha

![](https://github.com/Hugoch/flights-analysis/blob/master/flights_map_mpl.png)
